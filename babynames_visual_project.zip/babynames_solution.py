"""Визуализация Babynames 1880–2010 — задания 1–7, без Tkinter.

Запуск: python babynames_solution.py
Все диаграммы автоматически сохраняются в results/*.png.
В Google Colab используется launch_notebook() (ipywidgets, кнопка «Выход»).
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import FuncFormatter, MaxNLocator, PercentFormatter

START_YEAR, END_YEAR = 1880, 2010
COLS = ["name", "sex", "births"]
SEX = {"M": "Мужские", "F": "Женские"}
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["figure.dpi"] = 110


def data_directory() -> Path:
    base = Path(__file__).resolve().parent
    for candidate in (base / "babynames", base):
        if all((candidate / f"yob{year}.txt").is_file() for year in (START_YEAR, END_YEAR)):
            return candidate
    raise FileNotFoundError("Нет файлов yob1880.txt и yob2010.txt в папке babynames")


def parse_year(value: str) -> int | None:
    """Принимает только целое число 1880..2010, без десятичных и знака."""
    value = value.strip()
    if len(value) != 4 or not re.fullmatch(r"[0-9]{4}", value):
        return None
    number = int(value)
    return number if START_YEAR <= number <= END_YEAR else None


def read_year(folder: Path, year: int) -> pd.DataFrame:
    if year < START_YEAR or year > END_YEAR:
        raise ValueError("Год вне диапазона 1880–2010")
    return pd.read_csv(folder / f"yob{year}.txt", names=COLS, header=None,
                       dtype={"name": str, "sex": str, "births": "int64"}, keep_default_na=False)


def read_all(folder: Path) -> pd.DataFrame:
    """Задание 2: обязательно объединение методом pd.concat."""
    pieces = []
    for year in range(START_YEAR, END_YEAR + 1):
        part = read_year(folder, year)
        part["year"] = year
        pieces.append(part)
    return pd.concat(pieces, ignore_index=True)


def with_proportion(data: pd.DataFrame) -> pd.DataFrame:
    """Доля имени в рождённых того же пола и того же года."""
    result = data.copy()
    total = result.groupby(["year", "sex"], sort=False)["births"].transform("sum")
    result["proportion"] = result["births"] / total
    return result


def top_five(data: pd.DataFrame, sex: str | None, popular: bool) -> pd.DataFrame:
    """Группировка по имени за 131 год, разделение пола только для M/F.

    При ничьей выбираются первые по алфавиту: детерминированные ровно 5 строк.
    """
    if sex not in (None, "M", "F"):
        raise ValueError("sex: None, M или F")
    sample = data if sex is None else data.loc[data["sex"] == sex]
    grouped = sample.groupby("name", as_index=False)["births"].sum()
    return (grouped.sort_values(["births", "name"], ascending=[not popular, True], kind="mergesort")
            .head(5).reset_index(drop=True))


def number(value: float) -> str:
    return f"{int(value):,}".replace(",", " ")


def get_year_input(input_fn=input) -> int | None:
    """Ошибка ввода -> повторный запрос, '0'/'выход' -> выход в меню."""
    while True:
        try:
            raw = input_fn("Введите год (1880–2010), 0 — выход: ")
        except (EOFError, KeyboardInterrupt):
            print("\nВыход из выбора года.")
            return None
        if raw.strip().casefold() in ("0", "выход", "exit", "q"):
            return None
        year = parse_year(raw)
        if year is not None:
            return year
        print("Ошибка: введите только целое число от 1880 до 2010. Попробуйте ещё раз или 0 для выхода.")


class BabyNamesVisual:
    def __init__(self, folder: Path | None = None, result_dir: Path | None = None, show: bool = True):
        self.folder = folder or data_directory()
        self.result_dir = result_dir or Path(__file__).resolve().parent / "results"
        self.result_dir.mkdir(parents=True, exist_ok=True)
        self.show = show
        self._data: pd.DataFrame | None = None
        self._prop: pd.DataFrame | None = None
        self.generated: list[Path] = []

    @property
    def data(self) -> pd.DataFrame:
        if self._data is None:
            print("Загрузка данных за 1880–2010 годы…")
            self._data = read_all(self.folder)
        return self._data

    @property
    def proportion(self) -> pd.DataFrame:
        if self._prop is None:
            self._prop = with_proportion(self.data)
        return self._prop

    def chart(self, fig, filename: str) -> Path:
        fig.tight_layout()
        path = self.result_dir / filename
        fig.savefig(path, dpi=160, bbox_inches="tight")
        self.generated.append(path)
        print(f"Диаграмма сохранена: {path}")
        if self.show:
            plt.show()
        plt.close(fig)
        return path

    @staticmethod
    def bars(series: pd.Series, title: str, xlabel: str = "Количество", color=None):
        fig, ax = plt.subplots(figsize=(10, 5.3))
        rects = ax.barh(series.index.astype(str), series.values, color=color)
        ax.invert_yaxis()
        ax.set(title=title, xlabel=xlabel)
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x, _p: number(x)))
        max_val = max(series.values)
        ax.set_xlim(0, max_val * 1.2 if max_val else 1)
        ax.bar_label(rects, labels=[number(v) for v in series.values], padding=4, fontsize=10)
        ax.grid(axis="x", alpha=.18)
        ax.set_axisbelow(True)
        return fig

    def task1(self, year: int):
        """Рождения по полу за выбранный год + диаграмма."""
        frame = read_year(self.folder, year)
        groups = frame.groupby("sex")["births"].sum()
        values = pd.Series({"Мальчики": groups.get("M", 0), "Девочки": groups.get("F", 0)})
        print(f"\nЗАДАНИЕ 1: {year} год")
        for label, value in values.items():
            print(f"{label}: {number(value)}")
        print("Всего:", number(values.sum()))
        self.chart(self.bars(values, f"Задание 1. Число рождений по полу — {year}"), f"01_рождения_{year}.png")
        return values

    def task2(self):
        """DataFrame, year, pd.concat + диаграмма числа записей по годам."""
        data = self.data
        print(f"\nЗАДАНИЕ 2. DataFrame: {len(data):,} строк, {data.year.nunique()} лет")
        print(data.head(12).to_string(index=False))
        fig, ax = plt.subplots(figsize=(12, 5))
        per_year = data.groupby("year").size()
        ax.plot(per_year.index, per_year.values)
        ax.set(title="Задание 2. Число записей с именами в файлах по годам",
               xlabel="Год", ylabel="Количество строк DataFrame")
        ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _p: number(x)))
        ax.grid(alpha=.25)
        self.chart(fig, "02_dataframe_по_годам.png")
        return data

    def task3(self):
        """Итоги рождений по годам и полу + линейная диаграмма."""
        totals = (self.data.groupby(["year", "sex"])["births"].sum()
                  .unstack("sex", fill_value=0).reindex(columns=["M", "F"], fill_value=0))
        print("\nЗАДАНИЕ 3. Итоги рождений по годам: \n", totals.to_string())
        fig, ax = plt.subplots(figsize=(12, 5.5))
        for sex in ("M", "F"):
            ax.plot(totals.index, totals[sex], label=SEX[sex])
        ax.set(title="Задание 3. Динамика количества рождений по полу (1880–2010)",
               xlabel="Год", ylabel="Количество рождений")
        ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _p: number(x)))
        ax.grid(alpha=.25)
        ax.legend()
        self.chart(fig, "03_рождения_по_годам.png")
        return totals

    def task4(self, year: int = END_YEAR):
        """Новый столбец proportion + диаграмма на примере top-10 выбранного года."""
        data = self.proportion
        print("\nЗАДАНИЕ 4. Пример DataFrame со столбцом proportion: \n", data.head(12).to_string(index=False))
        selected = data.loc[data["year"] == year].nlargest(10, "proportion").copy()
        selected["label"] = selected["name"] + " (" + selected["sex"] + ")"
        series = selected.set_index("label")["proportion"] * 100
        fig, ax = plt.subplots(figsize=(10.5, 5.8))
        bars = ax.barh(series.index, series.values)
        ax.invert_yaxis()
        ax.bar_label(bars, labels=[f"{v:.2f}%" for v in series], padding=4)
        ax.set_xlim(0, max(series) * 1.2)
        ax.set(title=f"Задание 4. Доля 10 самых частых имён ({year} год)", xlabel="Доля рождений в своём поле, %")
        ax.grid(axis="x", alpha=.2)
        self.chart(fig, f"04_доля_имен_{year}.png")
        return data

    def task5(self, own_name: str = "Nikita"):
        """Две отдельные диаграммы: количество и доля имён."""
        own_name = own_name.strip().title()
        if not own_name or not re.fullmatch(r"[A-Za-z][A-Za-z'-]*", own_name):
            raise ValueError("Введите своё имя латиницей, например Nikita")
        names = list(dict.fromkeys(["Johnny", "Natalie", "Bob", own_name]))
        data = self.data
        selected = data.loc[data["name"].isin(names)]
        series = selected.groupby(["year", "name"])["births"].sum().unstack("name", fill_value=0)
        series = series.reindex(index=range(START_YEAR, END_YEAR + 1), columns=names, fill_value=0)
        year_total = data.groupby("year")["births"].sum().reindex(series.index)
        share = series.div(year_total, axis=0) * 100
        print("\nЗАДАНИЕ 5. Имена:", ", ".join(names))
        print("Доля берётся среди всех учтённых рождений за год, M+F.")
        print(series.tail(8).to_string())
        for values, ylabel, title, filename in [
            (series, "Количество рождений", "Количество рождений с выбранными именами", "05a_количество_имен.png"),
            (share, "Доля всех рождений, %", "Относительная доля выбранных имён", "05b_доли_имен.png"),
        ]:
            fig, ax = plt.subplots(figsize=(12, 5.5))
            for name in names:
                ax.plot(values.index, values[name], label=name, linewidth=1.8)
            ax.set(title="Задание 5. " + title + " (1880–2010)", xlabel="Год", ylabel=ylabel)
            ax.grid(alpha=.25)
            ax.legend()
            if values is share:
                ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _p: f"{x:g}%"))
            else:
                ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _p: number(x)))
            self.chart(fig, filename)
        return series, share

    def task6(self):
        """Первые имена каждого года и пола, включая случаи равенства."""
        data = self.data
        maximum = data.groupby(["year", "sex"])["births"].transform("max")
        leaders = data.loc[data["births"].eq(maximum), ["year", "sex", "name", "births"]].copy()
        leaders.sort_values(["year", "sex", "name"], inplace=True)
        print("\nЗАДАНИЕ 6. Самые популярные имена для каждого года и пола")
        print(leaders.to_string(index=False))
        leaders.to_csv(self.result_dir / "06_лидеры_по_годам.csv", index=False, encoding="utf-8-sig")
        fig, ax = plt.subplots(figsize=(12, 5.5))
        for sex in ("M", "F"):
            values = leaders.loc[leaders.sex == sex].groupby("year")["births"].max()
            ax.plot(values.index, values.values, label=SEX[sex])
        ax.set(title="Задание 6. Частота самого популярного имени по годам",
               xlabel="Год", ylabel="Число рождений с именем-лидером")
        ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _p: number(x)))
        ax.grid(alpha=.25)
        ax.legend()
        self.chart(fig, "06_лидеры_по_годам.png")
        return leaders

    def task7(self):
        """Шесть отдельных столбчатых диаграмм с точным количеством для каждого имени."""
        summaries = {}
        groups = [(None, "в целом", "общие"), ("M", "мужские", "мужские"),
                  ("F", "женские", "женские")]
        for popular, status, prefix in [(True, "популярных", "популярные"),
                                        (False, "редких", "редкие")]:
            for sex, label, file_word in groups:
                table = top_five(self.data, sex, popular)
                title = f"5 самых {status} имён — {label} (1880–2010)"
                print("\n" + title)
                print(table.to_string(index=False))
                key = f"{prefix}_{file_word}"
                summaries[key] = table
                filename = f"07_{key}.png"
                self.chart(self.bars(table.set_index("name")["births"], "Задание 7. " + title,
                                     "Количество рождений за весь период"), filename)
        print("\nВажно: редкие имена в SSA записаны, только если встречались не менее 5 раз в году.")
        return summaries


def launch_notebook(folder: str | Path | None = None):
    """Интерфейс для Google Colab/Jupyter: без Tkinter, с кнопкой выхода.

    Требует ipywidgets, обычно доступный в Google Colab.
    """
    import ipywidgets as widgets
    from IPython.display import display

    app = BabyNamesVisual(folder=Path(folder) if folder else None)
    year_field = widgets.Text(value="2010", description="Год:", layout=widgets.Layout(width="250px"))
    name_field = widgets.Text(value="Nikita", description="Имя:", layout=widgets.Layout(width="310px"))
    status = widgets.HTML(value="Введите год 1880–2010. При ошибке исправьте его и повторите ввод.")
    out = widgets.Output(layout={"border": "1px solid #ddd", "padding": "10px"})
    buttons = [widgets.Button(description=f"Задание {i}", button_style="info") for i in range(1, 8)]
    exit_btn = widgets.Button(description="Выход", button_style="danger")
    all_buttons = buttons + [exit_btn]
    title = widgets.HTML("<h3>Babynames: задания 1–7 (1880–2010)</h3>")

    def click_for(i):
        def handler(_):
            if i in (1, 4):
                year = parse_year(year_field.value)
                if year is None:
                    status.value = '<span style="color:#c00">Ошибка: только целое число от 1880 до 2010. Исправьте ввод либо нажмите «Выход».</span>'
                    return
            status.value = f"Выполняется задание {i}…"
            with out:
                out.clear_output(wait=True)
                try:
                    if i == 1: app.task1(year)
                    elif i == 2: app.task2()
                    elif i == 3: app.task3()
                    elif i == 4: app.task4(year)
                    elif i == 5: app.task5(name_field.value)
                    elif i == 6: app.task6()
                    else: app.task7()
                except Exception as exc:
                    status.value = f'<span style="color:#c00">Ошибка: {str(exc)}</span>'
                    print("Ошибка:", exc)
                else:
                    status.value = f"Задание {i} выполнено. Диаграммы находятся в папке results/."
        return handler

    for task, button in enumerate(buttons, 1):
        button.on_click(click_for(task))

    def close(_):
        for button in all_buttons:
            button.disabled = True
        year_field.disabled = name_field.disabled = True
        status.value = "Работа завершена."
        with out:
            out.clear_output()
    exit_btn.on_click(close)
    display(widgets.VBox([title, widgets.HBox([year_field, name_field]),
                          widgets.HBox(all_buttons[:4]), widgets.HBox(all_buttons[4:]), status, out]))
    return app


def self_check(folder: Path):
    assert [parse_year(x) for x in ("1880", " 2010 ", "2000")] == [1880, 2010, 2000]
    assert all(parse_year(x) is None for x in ("", "abc", "2011", "1879", "1880.5", "1e3", "-1880"))
    iterator = iter(("bad", "1879", "2011", "2010"))
    assert get_year_input(lambda _prompt: next(iterator)) == 2010
    assert get_year_input(lambda _prompt: "0") is None
    sample = pd.DataFrame({"name": ["Z", "Z", "A", "B", "C", "D", "E", "F", "G"],
                           "sex": ["M", "F", "F", "M", "M", "M", "F", "F", "F"],
                           "births": [5, 5, 10, 10, 9, 8, 7, 6, 5]})
    assert top_five(sample, None, True).iloc[0]["name"] == "A"  # tie -> alphabet
    assert top_five(sample, None, False).iloc[0]["name"] == "G"
    data = read_all(folder)
    assert len(data.year.unique()) == 131
    prop = with_proportion(data)
    assert ((prop.groupby(["year", "sex"]).proportion.sum() - 1).abs() < 1e-9).all()
    for sex in (None, "M", "F"):
        for popular in (True, False):
            assert len(top_five(data, sex, popular)) == 5
    print("Проверка успешна: 131 год, повторный ввод, все шесть рейтингов, proportion.")


def run_console(app: BabyNamesVisual):
    menu = "\nМеню: 1–7 — выполнить задание; 0 — выход\n"
    while True:
        try:
            action = input(menu + "Номер задания: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nРабота завершена.")
            return
        if action in ("0", "q", "выход", "exit"):
            print("Работа завершена.")
            return
        if action not in tuple(str(i) for i in range(1, 8)):
            print("Ошибка: выберите число от 1 до 7 или 0 для выхода.")
            continue
        try:
            if action == "1":
                year = get_year_input()
                if year is not None: app.task1(year)
            elif action == "2": app.task2()
            elif action == "3": app.task3()
            elif action == "4": app.task4()
            elif action == "5":
                name = input("Введите своё имя латиницей (Enter = Nikita): ").strip() or "Nikita"
                app.task5(name)
            elif action == "6": app.task6()
            else: app.task7()
        except (OSError, ValueError) as exc:
            print("Ошибка:", exc)


def main():
    parser = argparse.ArgumentParser(description="Babynames 1880–2010: диаграммы для заданий 1–7")
    parser.add_argument("--all", action="store_true", help="Сохранить диаграммы всех 7 заданий")
    parser.add_argument("--check", action="store_true", help="Проверить данные и расчёты")
    parser.add_argument("--no-show", action="store_true", help="Не открывать окна диаграмм: только PNG")
    parser.add_argument("--year", type=int, default=2010, help="Год для пакетного режима (1880–2010)")
    parser.add_argument("--name", default="Nikita", help="Своё имя латиницей")
    args = parser.parse_args()
    folder = data_directory()
    if args.check:
        self_check(folder)
        return
    app = BabyNamesVisual(folder, show=not args.no_show)
    if args.all:
        if not START_YEAR <= args.year <= END_YEAR: parser.error("Год должен быть в диапазоне 1880–2010")
        app.task1(args.year)
        app.task2()
        app.task3()
        app.task4(args.year)
        app.task5(args.name)
        app.task6()
        app.task7()
        print(f"\nГотово: создано {len(app.generated)} PNG-диаграмм в {app.result_dir}")
    else:
        run_console(app)


if __name__ == "__main__":
    main()
